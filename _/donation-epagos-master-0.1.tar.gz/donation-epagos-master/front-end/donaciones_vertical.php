<?php 
$current_uri = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

$status='';
if(isset($_GET['error_code'])){
	$status .='<div class="payment_status" style="border: 1px solid #0098ae;padding: 5px;margin-bottom: 20px;color:#dc3545;" align="center">';
	$status .='<div><b>Disculpe las molestias.</b></div>'; 
	$status .='<div>Hay algún problema durante el pago, Por favor, inténtelo de nuevo después de un tiempo o verifique el problema.</div>';
	if($_GET['error_description']!='')
	{
		$status .='<div>Mensaje de error : '.htmlspecialchars($_GET['error_description']).'</div>';	
	}
	
	$status .='</div>';
}
	

$content .= '
<style>#donation_unsubscribe_container , .lightbox {display: none;}</style>
<div class="donations vertical col-12 pb-4">
<a id="donation-section" name="donation-section"></a>
'.$status.'
	<form action="" method="POST" id="payment_form" name="payment_form">
		<input type="hidden" name="version" id="version" value="1.1" >
		<input type="hidden" name="payment_id" id="payment_id" value="4">
		<input type="hidden" name="payment_module_id" id="payment_module_id" value="" >
		<input type="hidden" name="action" id="action" value="charge" >
		<input type="hidden" name="business_key" id="business_key" value="">
		<input type="hidden" name="reference_business" id="reference_business" value="000001">
		<input type="hidden" name="token_business" id="token_business" value="anti-0009">
		<input type="hidden" name="token_id" id="token_mp_id" value="">
		<input type="hidden" name="method" id="method" value="card">
		<input type="hidden" name="donation_action" id="donation_action" value="donation_epagos_processing">	
		<input type="hidden" name="page" value="plugin-donation-epagos">	
		<input type="hidden" name="amount" id="amount" value="300">
		
		<input type="hidden" name="name" id="name" value="Donativo">
		<input type="hidden" name="last_name" id="last_name" value="Caritas">
		<input type="hidden" name="phone_number" id="phone_number" value="">
		<input type="hidden" name="description" id="description" value="Donativo Caritas.">
		<input type="hidden" name="return_url" id="return_url" value="' . $current_uri . '">
		<input type="hidden" name="state_name" id="state_name" value="Nuevo Leon">
		<input type="hidden" name="city_name" id="city_name" value="Monterrey">
		<input type="hidden" name="currency" id="currency" value="MXN">
		<input type="hidden" name="postal_code" id="postal_code" value="00012">
		<input type="hidden" name="country_code" id="country_code" value="MX">
		<input type="hidden" name="street" id="street" value="Calle">
		<input type="hidden" name="number_int" id="number_int" value="A3">
		<input type="hidden" name="suburb" id="suburb" value="Colonias">
		<input type="hidden" name="number_ext" id="number_ext" value="683">
		

		<div class="row">
		<div class="col-12">
			<div class="step mb-2">
				<h4><span>1</span> Selecciona la cantidad que deseas donar</h4>
				<ul class="quantity_select">
					<li data-qty="100" class="qty"><i class="fa fa-heart"></i> <strong>$100</strong></li>
					<li data-qty="300" class="qty selected"><i class="fa fa-heart"></i> <strong>$300</strong></li>
					<li data-qty="500" class="qty"><i class="fa fa-heart"></i> <strong>$500</strong></li>
				</ul>';
				/*
		$content .='
			 <div class="customqty mb-3">
			 	<label>Otra cantidad</label>
			 	<div class="input-group input-group-lg">
					<div class="input-group-prepend">
						<span class="input-group-text">$</span>
					</div>
					<input type="number" name="customqty" class="customqty-input form-control" placeholder="1,000" min="50" max="9999">
				</div>
			 </div>';
			 */
			
		$content .='<div class="d-none">
				<input type="number" class="quantity" name="quantity" value="300">
			</div>';
			/*
			$content .='
			<p class="text-center">
				<label>
					<input type="checkbox"  name="recurring" id="recurring" > Quiero que mi donación sea mensual
				</label>
				<span href="#" data-toggle="tooltip" data-placement="top" title="Las donaciones recurrentes se hacen cada mes, por la cantidad elegida en el indicador de la parte superior."><i class="fa fa-question-circle-o" ></i></span>
			</p>';
			* */

		$content .='</div>
	</div>
	<div class="col-12">
		<div class="step mb-2">
			<h4><span>2</span> Ingresa tus datos de contacto</h4>
			<div class="row">
				<div class="col-12 col-md-6">
					<label>Nombre completo</label>
					<input type="text" autocomplete="off" id="holder_name" data-checkout="cardholderName" class="form-control" placeholder="Como aparece en la tarjeta">
				</div>
				<div class="col-12 col-md-6">
					<label>Correo electrónico</label>
					<input type="email" name="email"  id="email" class="form-control" autocomplete="off" required >
				</div>
			</div>
		</div>
		<div class="step mb-2">
			<h4><span>3</span> Ingresa los datos de tu tarjeta de crédito o débito</h4>
			<div class="row card-js">
				<div class="col-12">
					<label>Número de tarjeta de débito o crédito</label>
					<ul class="paypment-options list-inline">
						<li class="list-inline-item"><img src="'.get_stylesheet_directory_uri().'/images/payment-visa.png"></li>
						<li class="list-inline-item"><img src="'.get_stylesheet_directory_uri().'/images/payment-mastercard.png"></li>
						<li class="list-inline-item"><img src="'.get_stylesheet_directory_uri().'/images/payment-amex.png"></li>
					</ul>
					<input type="text" autocomplete="off" id="card_number" data-checkout="cardNumber" class="form-control" placeholder="XXXX XXXX XXXX XXXX" maxlength="16">
				</div>
				<div class="col-6">
					<label>Fecha vencimiento</label>
					<div class="clearfix"></div>
					<div class="sctn-col half l">
						<input type="text" maxlength="2" class="form-control" placeholder="Mes" id="expiration_month" data-checkout="cardExpirationMonth">
					</div>
					<div class="sctn-col half l">
						<input type="text" maxlength="2" class="form-control" placeholder="Año" id="expiration_year" data-checkout="cardExpirationYear">
					</div>

				</div>
				<div class="col-6">
					<label>CCV <span href="#" data-toggle="tooltip" data-placement="top" title="El número de autorización se encuentra en la parte posterior de tu tarjeta, justo al lado de la barra de la firma."><i class="fa fa-question-circle-o" ></i></span></label>
					<input type="tel" maxlength="4" id="ccv" class="form-control" autocomplete="off" required placeholder="3 dígitos" data-checkout="securityCode">
				</div>
				<div class="col-12">
					<p>
					<label>
					<input type="checkbox" name="terms" id="terms" value="1" required> Acepto los <a href="/terminos.html" data-featherlight="ajax" data-featherlight-other-close="a.read.btn" >Términos y condiciones</a> de esta donación.
					</label>
					</p>
				</div>
			</div>
		</div>
		
	</div>
	<div class="col-12 text-center">
		<button id="pay-button" name="pay-button" class="btn btn-special btn-lg"><i class="fa fa-heart"></i> Quiero ayudar</button>';
/*
		$content .='
		<div class="text-center" style="padding-top:5px">			
		 	<a id="donation_unsubscribe_link" href="#donation_unsubscribe_box">Cancelar la donación</a>
		</div>';
*/
	$content .='</div>	
	</div>
	
</form>';
/*
$content .='
<div class="lightbox" id="donation_unsubscribe_box">
	<div id="donation_unsubscribe_div" style="padding:10px;text-align:center;">
	  <p>Por favor ingrese el correo electrónico para cancelar la donación.</p>
	  <p><input type="text" class="" style="width:100%;padding:5px;" placeholder="correo electrónico" name="email" id="email_unsubscribe"/></p>
	  <p><span id="error_msg"></span></p>
	  <p><button name="donation_unsubscribe" class="btn btn-secondary btn-center" id="donation_unsubscribe">Unsubscribe</button>
	  </p>
	</div>
</div>';
*/
if( isset($_GET['status']) && in_array($_GET['status'], array('completed', 'in_progress')) && $_GET['order_id']){
	$content .='<div class="lightbox" id="donation_confirmation_box">
					<div id="donation_confirmation_div" style="padding:10px;text-align:left;">';

					if($_GET['status'] == 'in_progress')
					{
						$content .='<div><b>Tu donación está siendo procesada. Gracias por su apoyo.</b></div>';		
					}							
					else if($_GET['status'] == 'completed'){
						$content .='<div><b>Su donación se procesa con éxito. Gracias por su apoyo.</b></div>';		
					}		
						
					$content .='<br/>';
					$content .='<div>Número de orden de donación:<b>'.htmlspecialchars($_GET['order_id']).'</b></div>';

					if($_GET['request_id'])
					{
						$content .='<div>Número de referencia:<b>'.htmlspecialchars($_GET['request_id']).'</b></div>';
					}
					if($_GET['request_id'])
					{
						$content .='<div>Número de autorización:<b>'.htmlspecialchars($_GET['authorization']).'</b></div>';
					}

					if($_GET['next_payment_date'])
					{
						$content .='<div>Siguiente fecha de carga:<b>'.htmlspecialchars($_GET['next_payment_date']).'</b></div>';
					}

					if($_GET['amount'])
					{
						$content .='<div>Monto de donación:<b> $'.htmlspecialchars($_GET['amount']).'</b></div>';
					}
					if($_GET['msg'])
					{
						$content .='<div>Mensaje:<b> '.htmlspecialchars($_GET['msg']).'</b></div>';
					}		
					$content .='<br/><div><i>Recibirá un correo electrónico para obtener más información.</i></div>';

					$content.='<div style="margin-top:20px;"><button id="confirm-button" name="confirm-button" onclick="closeFeatherBox();" align="center" class="btn btn-special btn-lg"><i class="fa fa-heart"></i>&nbsp;Aceptar</button></div>';

	$content.='</div></div>';				

}

if(isset($_GET['error_code'])){

	$content .='<div class="lightbox" id="donation_confirmation_box"><div class="payment_status" style="padding: 5px;margin-bottom: 20px;color:#dc3545;" align="left">';
	$content .='<div><b>Disculpe las molestias.</b></div>'; 
	$content .='<div>Hay algún problema durante el pago, Por favor, inténtelo de nuevo después de un tiempo o verifique el problema.</div>';
	if($_GET['error_description']!='')
	{
		$content .='<div>Mensaje de error : '.htmlspecialchars($_GET['error_description']).'</div>';	
	}
	
	$content.='<div style="margin-top:20px;"><button id="confirm-button" name="confirm-button" onclick="closeFeatherBox();" align="center" class="btn btn-special btn-lg"><i class="fa fa-plus-circle"></i>&nbsp;Rever</button></div>';
	
	$content .='</div></div>';
} 


$content .= '</div>';

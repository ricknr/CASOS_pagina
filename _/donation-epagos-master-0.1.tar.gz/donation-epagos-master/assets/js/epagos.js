// inicializar varieble $ con jquery para e-pagos
var $ = jQuery.noConflict();
jQuery(document).ready(function() {

    if(donation_epagos_params.epagos_enabled)
    {
        jQuery('#payment_form').attr('action', donation_epagos_params.form_action);
        jQuery('#business_key').val(donation_epagos_params.business_id);
        jQuery('#payment_module_id').val(donation_epagos_params.payment_id);
        jQuery('.payment_status').hide();

    }else
    {
        jQuery('.payment_status').show();
        jQuery('#pay-button').prop('disabled',true);
    }
    
	$("#payment_form").on("submit", function(e){
		$("#pay-button").prop('disabled', true);

		/* Validación plan y suscripción */
		var error_ = 0;
		if(!$("#token_mp_id").val() &&  ! error_){
			e.preventDefault();
			if (typeof(validateMercadopago) !== "undefined"){
				validateMercadopago();
			}
			else{
				alert('error');
			}
		}
	});
	
    var status = param('status');
    var err = param('error_code');
    if((status!="" && (status==='completed' || status==='in_progress' )) || err != "")
    {
        setTimeout(function(){ 

            jQuery('html, body').animate({ scrollTop: 0 }, 'slow');
            jQuery.featherlight('#donation_confirmation_box');

        },3000);
        
    }

});

function mercadopagoCompleteCallback(data){
	$("#payment_form").submit();
}
function mercadopagoErrorCallback(data){
	$("#pay-button").prop('disabled', false);
	alert(data.error_description);
}

function param(name) {
    return (location.search.split(name + '=')[1] || '').split('&')[0];
}

function isEmail(email) {    

  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
  return regex.test(email);
  
}

function closeFeatherBox(){
    var current = jQuery.featherlight.current();
    current.close();    
}


<?php

// Prepare array with options
	global $options_epagos;
	$options_epagos = array(
		// Open tab: Subscription
		array(
			'type' => 'opentab',
			'id'=>'subscription',
			'name' => __( 'Subscription', 'plugin-donation-epagos' ),
		),
		// Open tab: One time
		array(
			'type' => 'opentab',
			'id'=>'onetime',
			'name' => __( 'One Time', 'plugin-donation-epagos' ),
		),	

		// Open tab: Settings 
		array(
			'type' => 'opentab',
			'id'=>'settings',
			'name' => __( 'Configuración', 'plugin-donation-epagos' ),
		),

		// Checkbox
		array(
			'id'      => 'epagos_enabled',
			'type'    => 'checkbox',
			'default' => 'on',
			'name'    => __( 'Estatus', 'plugin-donation-epagos' ),
			'desc'    => __( 'Activar motor de pagos de Epagos', 'plugin-donation-epagos' ),
			'label'   => __( 'Activo / Inactivo', 'plugin-donation-epagos' ),
		),

		// Checkbox
		//~ array(
			//~ 'id'      => 'epagos_testmode',
			//~ 'type'    => 'checkbox',
			//~ 'default' => 'on',
			//~ 'name'    => __( 'Sandbox mode', 'plugin-donation-epagos' ),
			//~ 'desc'    => __( 'Activo test mode', 'plugin-donation-epagos' ),
			//~ 'label'   => __( 'Sandbox mode', 'plugin-donation-epagos' ),
		//~ ),

		// Text field
		array(
			'id'      => 'epagos_business_id',
			'type'    => 'text',
			'default' => '',
			'name'    => __( 'Id de negocio', 'plugin-donation-epagos' ),
			'desc'    => __( 'Id de negocio proporcionado por e-pagos.', 'plugin-donation-epagos' ),
			'placeholder'=>__('Id de negocio','plugin-donation-epagos'),
		),

		// Text field
		array(
			'id'      => 'epagos_payment_id',
			'type'    => 'text',
			'default' => '',
			'name'    => __( 'Id de motor de pago', 'plugin-donation-epagos' ),
			'desc'    => __( 'Id de motor de pago proporcionado por e-pagos.', 'plugin-donation-epagos' ),
			'placeholder'=>__('Id de motor de pago','plugin-donation-epagos'),
		),

		// Text field
		array(
			'id'      => 'epagos_app_domain',
			'type'    => 'text',
			'default' => 'https://epagos.mx',
			'name'    => __( 'Url de e-pagos', 'plugin-donation-epagos' ),
			'desc'    => __( 'Url de e-pagos a la cual se conectará el servicio.', 'plugin-donation-epagos' ),
			'placeholder'=>__('Url de e-pagos','plugin-donation-epagos'),
		),

	//Close tab: Extra fields
	array(
	 		'type' => 'closetab',
	 	)
	 );
